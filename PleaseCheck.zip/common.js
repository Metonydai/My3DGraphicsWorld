
async function loadComponent(elementId, filePath, callback, isSubPage=false) {
    try {
        const response = await fetch(filePath);
        if (response.ok) {
            let html = await response.text();
            
            if (isSubPage) {
                html = html.replace(/href="(?!http|https|\/\/)/g, 'href="../');
            }

            document.getElementById(elementId).innerHTML = html;
            if (callback) callback();
        }
    } catch (e) { console.error(e); }
}


// 1. 初始化語系（default en）
if (!localStorage.getItem("CURRENT_LANG")) {
    localStorage.setItem("CURRENT_LANG", "en");
}

// 2. 全站共用：取得當前語系文字的防呆工具（供 projects.js 使用）
function getLangText(obj) {
    if (!obj) return "";
    const currentLang = localStorage.getItem("CURRENT_LANG");
    return obj[currentLang] || obj["en"] || ""; // 優先拿當前語系，沒有就拿英文
}

// 3. 全站共用：刷新全站「畫面上」的語系顯示
function updateGlobalLanguageDOM() {
    const currentLang = localStorage.getItem("CURRENT_LANG");

    // A. 切換畫面上帶有特定語系 class 的元件顯示隱藏
    document.querySelectorAll(".lang-zh").forEach(el => {
        el.style.display = (currentLang === "zh") ? "block" : "none";
    });
    document.querySelectorAll(".lang-en").forEach(el => {
        el.style.display = (currentLang === "en") ? "block" : "none";
    });

    // B. 更新右上角切換按鈕的文字狀態
    const langBtn = document.getElementById("global-lang-btn");
    if (langBtn) {
        langBtn.textContent = (currentLang === "zh") ? "EN" : "繁中";
    }
}

// 4. 全站共用：建立與綁定右上角切換按鈕
function setupLanguageSwitcher() {
    // 尋找導覽列或頁面右上角的放置點
    const header = document.getElementById("header-container");
    if (!header) return;

    // 如果畫面上還沒有按鈕，就動態塞入一個
    if (!document.getElementById("global-lang-btn")) {
        const btn = document.createElement("button");
        btn.id = "global-lang-btn";
        btn.className = "lang-switch-btn"; // 可以在 style.css 設計它的外觀
        
        // 綁定點擊事件
        btn.addEventListener("click", () => {
            const oldLang = localStorage.getItem("CURRENT_LANG");
            const newLang = (oldLang === "zh") ? "en" : "zh";
            localStorage.setItem("CURRENT_LANG", newLang);
            
            // 點擊後重新載入或重刷畫面
            window.location.reload(); 
        });
        
        header.appendChild(btn);
    }
    updateGlobalLanguageDOM();
}


// 2. 每篇 Post 頁面專屬的自動化統籌函式
function initPostPage(postId) {
    document.addEventListener("DOMContentLoaded", () => {
        
        // A. 載入 Header (人在子目錄，所以最後參數帶 true)
        loadComponent("header-container", "../header.html", () => {
            const activeNav = document.getElementById("nav-mywork");
            if (activeNav) activeNav.classList.add("active");
        }, true);

        // B. 載入 Sidebar
        loadComponent("sidebar-container", "../sidebar.html", () => {
            // 這裡呼叫 projects.js 裡的 initSidebar，因為人在子目錄，傳入空字串 ""
            if (typeof initSidebar === "function") {
                initSidebar(""); 
            }
        }, true);

        // C. 依據 postId 自動從 projects.js 撈資料填入網頁
        if (window.GLOBAL_PROJECTS) {
            // 從全域資料庫比對 id
            const project = window.GLOBAL_PROJECTS.find(p => p.id === postId);
            
            if (project) {
                // 取得當前語系的文字（呼叫 projects.js 裡的 getLangText）
                const titleText = getLangText(project.title);
                const catText = getLangText(project.category);
                
                // 動態改寫瀏覽器分頁的標題 (<title>)
                document.title = `${titleText} - My 3D Graphics World`;

                // 自動填入網頁內文的大標題 (H1)
                const titleElement = document.getElementById("post-dynamic-title");
                if (titleElement) titleElement.textContent = titleText;

                // 自動填入網頁內文的日期與分類資訊
                const metaElement = document.getElementById("post-dynamic-meta");
                if (metaElement) {
                    metaElement.textContent = `Date: ${project.date} | Category: ${catText}`;
                }
            }
        }
    });
}